alert("Calcular média")

var nota1, nota2, nota3, media;

nota1 = prompt ("Nota 1: ");
nota2 = prompt ("Nota 2: ");
nota3 = prompt ("Nota 3: ");

media = (parseFloat (nota1) + parseFloat (nota2) + parseFloat (nota3)) / 3;

var decisao = confirm("As notas estão corretas? ");

if (decisao){
    alert(media.toFixed(2));
}