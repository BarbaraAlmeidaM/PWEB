alert("Calculando as Operações")

var num1, num2, soma, sub, prdt, div, rest;

num1 = prompt ("Número 1: ");
num2 = prompt ("Número 2: ");

soma = parseFloat(num1) + parseFloat (num2);
alert("Soma dos dois número: " + soma.toFixed(2));

sub = parseFloat(num1) - parseFloat (num2);
alert("Subtração do primeiro pelo segundo: " + sub.toFixed(2));

prdt = parseFloat (num1) * parseFloat (num2);
alert ("Produto dos dois números: " + prdt.toFixed(2));

div = parseFloat (num1) / parseFloat (num2);
alert ("Divisão do primeiro pelo segundo: " + div.toFixed(2));

rest = parseFloat (num1) % parseFloat (num2);
alert ("O resto da divisão do primeiro pelo segundo: " + rest.toFixed(2));
