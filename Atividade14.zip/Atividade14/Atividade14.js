var form = document.getElementById("form");
var email = document.getElementById("idEmail");
var comentario = document.getElementById("idComentario");
var pesquisa = document.getElementsByName("pesquisa");

function validar(){
    if (document.forms.form.elements[0].value == "" || document.forms.form.elements[0].value.length < 10) {
        alert("Preencha o campo nome corretamente!");
        return false;
    };

    if (email.value.indexOf('@') == -1 || email.value.indexOf('.') == -1 || email.value == "") {
        alert("Preencha o campo email corretamente!");
        return false;
    }

    if (comentario.value.length < 20) {
        alert("Preencha o campo comentário corretamente!");
        return false;
    }

    for(var i = 0; i < pesquisa.length; i++){
        if(pesquisa[i].checked){
            if(pesquisa[i].value == "positivo"){
                alert("Que bom que você voltou a visitar a página!");
                return true;
            }else{
                alert("Volte sempre à esta página!");
                return true;
            }
        }else if(i == pesquisa.length-1){
                alert("Selecione uma opção para a Pesquisa!");
                return false;
            }
    }
}