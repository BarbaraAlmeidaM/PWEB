var aluno1 = new Object();
aluno1.ra = 2828282;
aluno1.nome = "Louis William Tomlinson";

var aluno2 = {};
aluno1.ra = 6969696;
aluno1.nome = "Harry Edward Styles";

var aluno3 = {
     ra : 1818181,
    nome : "Zayn Javaad Malik"
};

alert ("Veja o código!");