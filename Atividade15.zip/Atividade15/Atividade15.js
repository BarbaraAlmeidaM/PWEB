selecao = document.getElementById("selecao");

selecao.onchange = function () {

    if (selecao.value != "padrao") {
        var confirmacao = confirm("Deseja ver este curso?");

        if (confirmacao) {
            switch (selecao.value) {
                case "1":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_ads.asp", "pagina1", "width = 600, height = 300");
                    break;
                case "2":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_ea.asp", "pagina2", "width = 600, height = 300");
                    break;
                case "3":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_fm.asp", "pagina3", "width = 600, height = 300");
                    break;
                case "4":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_gq.asp", "pagina4", "width = 600, height = 300");
                    break;
                case "5":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_ma.asp", "pagina5", "width = 600, height = 300");
                    break;
                case "6":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_log.asp", "pagina6", "width = 600, height = 300");
                    break;
                case "7":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_pm.asp", "pagina7", "width = 600, height = 300");
                    break;
                case "8":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_pol.asp", "pagina8", "width = 600, height = 300");
                    break;
                case "9":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_proj.asp", "pagina9", "width = 600, height = 300");
                    break;
                case "10":
                    pagina = window.open("http://www.fatecsorocaba.edu.br/curso_sb.asp", "pagina5", "width = 600, height = 300");
                    break;
            }
        }
    }
}