var escolha;


escolha = prompt("1- Pedra \n2- Papel\n3- Tesoura");

var escolhapc = Math.random();
console.log(escolhapc)
if(escolha == 1){
    if(escolhapc >= 0 && escolhapc <= 0.33){
        alert ("Máquina escolheu Pedra: Empate");
    }else if (escolhapc > 0.33 && escolhapc <= 0.66){
        alert ("Máquina escolheu Papel: Máquina ganhou");
    }else{
        alert ("Máquina escolheu Tesoura: Você ganhou");
    }
}else if (escolha == 2){
    if(escolhapc >= 0 && escolhapc <= 0.33){
        alert ("Máquina escolheu Pedra: Você ganhou");
    }else if (escolhapc > 0.33 && escolhapc <= 0.66){
        alert ("Máquina escolheu Papel: Empate");
    }else{
        alert ("Máquina escolheu Tesoura: Máquina ganhou");
    }
}else if (escolha == 3){
    if(escolhapc >= 0 && escolhapc <= 0.33){
        alert ("Máquina escolheu Pedra: Máquina ganhou");
    }else if (escolhapc > 0.33 && escolhapc <= 0.66){
        alert ("Máquina escolheu Papel: Você ganhou");
    }else{
        alert ("Máquina escolheu Tesoura: Empate");
    }
}