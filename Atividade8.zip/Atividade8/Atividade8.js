var decisao = confirm ("Inserir as 45 pessoas? ");
var contIdade = 0;
var IdadeVelha = 0;
var IdadeNova = 1000;
var QtdePessimo = 0;
var QtdeOB = 0;
var QtdeMen = 0;
var QtdeWoman = 0;

if(decisao){
    var idade;
    var sexo;
    var opiniao;

    for(var i = 0; i < 3; i = i + 1){
        console.log(i);

        idade = parseInt (prompt ("Insira a idade: ")); 
        sexo = parseInt (prompt ("Insira o sexo 1M, 2F: "));
        opiniao = parseInt (prompt("Insira opinião: ótimo=4, bom=3, regular=2, péssimo=1"));

        contIdade = contIdade + idade;

        if(idade > IdadeVelha){
            IdadeVelha = idade;
        }

        if(idade < IdadeNova){
            IdadeNova = idade;
        }

        if(opiniao == 1){
            QtdePessimo = QtdePessimo + 1;
        }

        if(opiniao == 4 || opiniao == 3){
            QtdeOB = QtdeOB + 1;
        }
        if (sexo == 1){
            QtdeMen = QtdeMen + 1;
        }else if(sexo == 2){
            QtdeWoman = QtdeWoman + 1;
        }
    }
    alert ("Média idade pessoas: " + Math.round(contIdade / 3));
    alert ("Pessoa mais velha: " + IdadeVelha);
    alert ("Pessoa mais nova: " + IdadeNova);
    alert ("Quantidade de pessoas que responderam péssimo: " + QtdePessimo);
    alert ("Porcentagem de pessoas que responderam ótimo e bom: " + Math.round((QtdeOB / 3) * 100) + "%");
    alert ("Quantidade de homens: " + QtdeMen);
    alert ("Quantidade de mulheres: " + QtdeWoman);
}