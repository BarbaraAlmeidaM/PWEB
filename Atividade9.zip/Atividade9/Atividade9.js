var num1 = parseInt(prompt("Insira o primeiro número: "));
var num2 = parseInt (prompt ("Insira o segundo número: "));
var num3 = parseInt (prompt ("Insira o terceiro número: "));
var numMaior;
var Ordemcrescente;

numMaior = maior(num1, num2, num3);

alert ("Maior número: " + numMaior);

ordemCrescente();

maior();

function maior(a, b, c){
    Ordemcrescente = [num1, num2, num3];

    var x =Math.max(...Ordemcrescente)

    return x;
    
}

function ordemCrescente(){
    Ordemcrescente = [num1, num2, num3];

    Ordemcrescente.sort((a,b)=>{
        return a-b;
    });

    alert (Ordemcrescente);
}